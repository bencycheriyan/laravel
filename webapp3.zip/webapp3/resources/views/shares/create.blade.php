<!DOCTYPE html>
<html>
<head>
	<title>Create</title>
</head>
<body>
<form method="post" action="{{route('shares.store')}}">
	@csrf
	<table border="1">
		<tr>
			<td>Title</td>
			<td><input type="text" name="title"> </td>
		</tr>
		<tr>
		<td>body</td>
		<td><input type="text" name="body"> </td>
	     </tr>
	     <tr>
	     	<td></td>
	     	<td><input type="submit" name="title" value="click"></td>
	     </tr>

	</table>
</form>
</body>
</html>