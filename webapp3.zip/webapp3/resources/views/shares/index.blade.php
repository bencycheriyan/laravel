<table border="1">
	<tr>
		<td>id</td>
		<td>Title</td>
		<td>body</td>
		<td>Edit</td>
		<td>Delete</td>

	</tr>
	@foreach($share as $value)
	<tr>
		<td>{{$value->id}}</td>
		<td>{{$value->title}}</td>
		<td>{{$value->body}}</td>
	</tr>
	@endforeach
</table>