<table border="1">
	<tr>
		<td>id</td>
		<td>Title</td>
		<td>body</td>
		<td>Edit</td>
		<td>Delete</td>

	</tr>
	<?php $__currentLoopData = $share; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($value->id); ?></td>
		<td><?php echo e($value->title); ?></td>
		<td><?php echo e($value->body); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>